package com.example.marketplace.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.marketplace.R;
import com.example.marketplace.adapter.ProductAdapter;
import com.example.marketplace.model.Product;
import com.example.marketplace.network.MarketplaceClient;
import com.example.marketplace.network.MarketplaceInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BuyActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    RecyclerView productsRecyclerView;
    private ProductAdapter productAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        MarketplaceInterface marketplaceInterface = MarketplaceClient.getMarketplaceInstance().create(MarketplaceInterface.class);
        Call<List<Product>> listCall = marketplaceInterface.getAllProducts();
        listCall.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if (response.code() == 200) {
                    getProductsData(response.body());
                    productAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {

            }
        });

    }

    private void getProductsData(List<Product> body) {
        productsRecyclerView = findViewById(R.id.product_list);
        productAdapter = new ProductAdapter(body);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, 2);
        productsRecyclerView.setLayoutManager(layoutManager);
        productsRecyclerView.setAdapter(productAdapter);

    }

}
