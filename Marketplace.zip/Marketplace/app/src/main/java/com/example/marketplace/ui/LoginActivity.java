package com.example.marketplace.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

import com.example.marketplace.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    @BindView(R.id.email_address)
    TextInputEditText mUsername;
    @BindView(R.id.password)
    TextInputEditText mPassword;
    @BindView(R.id.signed_in)
    CheckBox mCheckBox;
    @BindView(R.id.btn_sign_in)
    MaterialButton mSignin;

    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;
    //Firebase
    private FirebaseAuth mAuth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        //Instantiate
        mAuth = FirebaseAuth.getInstance();

        //declaring (database)
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        //mPreferences = getSharedPreferences("app", Context.MODE_PRIVATE);
        //used for inserting data into the (database)
        mEditor = mPreferences.edit();

        checkSharePreferences();


        mSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMainActivity();
                if (mCheckBox.isChecked()) {

                    //Sets checkbox when the application starts
                    mEditor.putString(getString(R.string.checkbox), "True");
                    mEditor.commit();

                    //Save the user name
                    String username = Objects.requireNonNull(mUsername.getText()).toString();
                    mEditor.putString(getString(R.string.user_name), username);
                    mEditor.commit();

                    //Save the password

                    String password = Objects.requireNonNull(mPassword.getText()).toString();
                    mEditor.putString(getString(R.string.pasword), password);
                    mEditor.commit();
                } else {
                   // Sets checkbox when the application starts
                    mEditor.putString(getString(R.string.checkbox), "False");
                    mEditor.commit();

                    //Save the user name
                    String username = Objects.requireNonNull(mUsername.getText()).toString();
                    mEditor.putString(getString(R.string.user_name), "");
                    mEditor.commit();

                    //Save the password

                    String password = Objects.requireNonNull(mPassword.getText()).toString();
                    mEditor.putString(getString(R.string.pasword), "");
                    mEditor.commit();
                }
            }
        });

        

    }


    private void startMainActivity() {
        String username = Objects.requireNonNull(mUsername.getText()).toString();
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
    }

    private void checkSharePreferences() {
        String checkbox = mPreferences.getString(getString(R.string.checkbox),"false");
        String user_name = mPreferences.getString(getString(R.string.user_name), "");
        String password = mPreferences.getString(getString(R.string.pasword), "");

        mUsername.setText(user_name);
        mPassword.setText(password);
        if (checkbox.equals("True")) {
            mCheckBox.setChecked(true);
        }else {
            mCheckBox.setChecked(false);
        }


    }

    public void openRegisterActivity(View view) {
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
    }
}
