package com.example.marketplace.ui;

import com.example.marketplace.BuildConfig;

public class Constant {
    public static final String BEST_BUY_API_KEY = BuildConfig.BEST_BUY_API_KEY;
}
